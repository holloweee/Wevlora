/**
 * Celestial Glass Studio — shared site shell.
 * The original Wevlora logo is the fixed brand anchor across every route.
 */
import { useState } from "react";
import { ArrowUpRight, Menu, MoveUpRight, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import ScrollEffects from "@/components/ScrollEffects";

const originalLogo = "/manus-storage/wevlora-original-logo_e26a28b1.jpg";

const routes = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Work", href: "/work" },
];

export default function SpaceShell({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="space-site">
      <div className="starfield" aria-hidden="true" />
      <div className="starfield starfield-soft" aria-hidden="true" />
      <header className={`space-nav ${menuOpen ? "is-open" : ""}`}>
        <Link href="/" className="space-brand" onClick={closeMenu} aria-label="Wevlora home">
          <span className="space-brand-logo"><img src={originalLogo} alt="" /></span>
          <span className="space-brand-name">wevlora</span>
        </Link>
        <nav className="space-desktop-nav" aria-label="Primary navigation">
          {routes.map((route) => (
            <Link key={route.href} href={route.href} className={`space-nav-link ${location === route.href ? "is-active" : ""}`}>
              <span className="space-nav-code">0{routes.indexOf(route) + 1}</span>
              <span>{route.label}</span>
            </Link>
          ))}
        </nav>
        <Link className="space-contact-link" href="/contact">
          <span>Start a project</span>
          <ArrowUpRight size={15} />
        </Link>
        <button
          className="space-menu-toggle"
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-controls="space-mobile-nav"
          aria-label={menuOpen ? "Close navigation" : "Open navigation"}
        >
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
        <nav className="space-mobile-nav" id="space-mobile-nav" aria-label="Mobile navigation">
          {routes.map((route) => (
            <Link key={route.href} href={route.href} onClick={closeMenu} className={`space-mobile-link ${location === route.href ? "is-active" : ""}`}>
              <span>{route.label}</span><ArrowUpRight size={16} />
            </Link>
          ))}
          <Link href="/contact" onClick={closeMenu} className="space-mobile-link mobile-link-accent">
            <span>Start a project</span><ArrowUpRight size={16} />
          </Link>
        </nav>
      </header>

      <div className="space-page-shell"><ScrollEffects />{children}</div>

      <footer className="space-footer">
        <Link href="/" className="space-footer-brand">
          <span className="space-footer-logo"><img src={originalLogo} alt="" /></span>
          <span>wevlora</span>
        </Link>
        <p>© 2026 Wevlora Creative Agency · West Bengal, India</p>
        <Link className="space-footer-link" href="/contact">Open a conversation <MoveUpRight size={14} /></Link>
      </footer>
    </div>
  );
}

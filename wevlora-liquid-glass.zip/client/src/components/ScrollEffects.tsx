/**
 * Celestial Glass Studio — scroll interaction controller.
 * Reveals meaningful content as it enters the viewport and exposes lightweight scroll progress
 * variables for orbital and glass depth movement. All non-essential motion respects reduced motion.
 */
import { useEffect } from "react";
import { useLocation } from "wouter";

const revealSelector = [
  "main.page > section",
  ".proof-card",
  ".route-panel",
  ".service-orbit-row",
  ".process-panel",
  ".creator-card",
  ".principle-card",
  ".contact-channel",
].join(",");

export default function ScrollEffects() {
  const [location] = useLocation();

  useEffect(() => {
    const root = document.querySelector<HTMLElement>(".space-site");
    if (!root) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const revealElements = Array.from(document.querySelectorAll<HTMLElement>(revealSelector));
    revealElements.forEach((element, index) => {
      element.classList.add("scroll-reveal");
      element.style.setProperty("--reveal-delay", `${Math.min(index % 6, 5) * 70}ms`);
    });

    if (reduceMotion) {
      revealElements.forEach((element) => element.classList.add("is-revealed"));
      root.style.setProperty("--page-progress", "0");
      root.style.setProperty("--hero-progress", "0");
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-revealed");
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" },
    );
    revealElements.forEach((element) => observer.observe(element));

    let frame = 0;
    const updateScrollProgress = () => {
      frame = 0;
      const maxScroll = Math.max(document.documentElement.scrollHeight - window.innerHeight, 1);
      const pageProgress = Math.min(Math.max(window.scrollY / maxScroll, 0), 1);
      const hero = document.querySelector<HTMLElement>("main.page > section:first-child");
      const heroHeight = hero?.offsetHeight ?? window.innerHeight;
      const heroProgress = Math.min(Math.max(window.scrollY / Math.max(heroHeight * 0.86, 1), 0), 1);
      root.style.setProperty("--page-progress", pageProgress.toFixed(4));
      root.style.setProperty("--hero-progress", heroProgress.toFixed(4));
    };
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(updateScrollProgress);
    };

    updateScrollProgress();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [location]);

  return null;
}

/**
 * Celestial Glass Studio — reusable interactive 3D object.
 * Signature objects continuously drift in idle state and route somewhere useful when activated.
 */
import { useState, type CSSProperties, type KeyboardEvent, type PointerEvent } from "react";
import { useLocation } from "wouter";

export type SpaceObjectVariant = "blackhole" | "terrarium" | "planet";

type InteractiveSpaceObjectProps = {
  src?: string;
  alt: string;
  variant: SpaceObjectVariant;
  label: string;
  detail?: string;
  destination?: string;
  actionLabel?: string;
  className?: string;
};

function CssSpaceArt({ variant }: { variant: SpaceObjectVariant }) {
  if (variant === "terrarium") {
    return (
      <div className="css-space-art css-terrarium-art" aria-hidden="true">
        <div className="terrarium-dome"><span className="terrarium-glint" /></div>
        <div className="terrarium-soil" />
        <div className="terrarium-plant"><i /><i /><i /><i /><i /><b /></div>
      </div>
    );
  }

  if (variant === "planet") {
    return (
      <div className="css-space-art css-planet-art" aria-hidden="true">
        <div className="planet-sphere"><span className="planet-highlight" /></div>
        <span className="planet-ring planet-ring-a" />
        <span className="planet-ring planet-ring-b" />
      </div>
    );
  }

  return null;
}

export default function InteractiveSpaceObject({ src, alt, variant, label, detail, destination, actionLabel, className = "" }: InteractiveSpaceObjectProps) {
  const [, setLocation] = useLocation();
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isEngaged, setIsEngaged] = useState(false);
  const target = destination ?? (variant === "terrarium" ? "/about" : variant === "planet" ? "/services" : "/contact");
  const action = actionLabel ?? (variant === "terrarium" ? "Meet the team" : variant === "planet" ? "Explore services" : "Start a project");

  const updateTilt = (event: PointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
    setTilt({ x: y * -9, y: x * 12 });
  };

  const resetTilt = () => {
    setTilt({ x: 0, y: 0 });
    setIsEngaged(false);
  };

  const activate = () => {
    if (/^(mailto:|tel:|https?:\/\/)/.test(target)) {
      window.location.href = target;
      return;
    }
    setLocation(target);
  };
  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      activate();
    }
  };

  const style = {
    "--object-tilt-x": `${tilt.x}deg`,
    "--object-tilt-y": `${tilt.y}deg`,
  } as CSSProperties;

  return (
    <div
      className={`interactive-space-object object-${variant} ${isEngaged ? "is-engaged" : ""} ${className}`}
      style={style}
      onPointerMove={updateTilt}
      onPointerEnter={() => setIsEngaged(true)}
      onPointerLeave={resetTilt}
      onPointerDown={() => setIsEngaged(true)}
      onPointerUp={() => setIsEngaged(false)}
      onPointerCancel={resetTilt}
      onClick={activate}
      onKeyDown={handleKeyDown}
      role="button"
      tabIndex={0}
      aria-label={`${label}. ${alt}. ${action}.`}
    >
      <div className="object-orbit orbit-a" aria-hidden="true" />
      <div className="object-orbit orbit-b" aria-hidden="true" />
      <div className="object-depth object-depth-back" aria-hidden="true" />
      <div className="object-depth object-depth-front" aria-hidden="true" />
      {src ? <img src={src} alt="" className="object-image" draggable={false} /> : <CssSpaceArt variant={variant} />}
      <div className="object-specular" aria-hidden="true" />
      <div className="object-label glass-label"><span>{label}</span>{detail ? <small>{detail}</small> : null}<b>{action}</b></div>
      <div className="object-cursor-hint" aria-hidden="true">Drag / click to {action.toLowerCase()}</div>
    </div>
  );
}

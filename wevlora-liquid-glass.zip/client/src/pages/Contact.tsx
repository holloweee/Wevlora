/**
 * Celestial Glass Studio — Contact page.
 * A direct, high-contrast invitation dock with the real Wevlora contact routes.
 */
import { ArrowUpRight, Instagram, Mail, Phone } from "lucide-react";
import { Link } from "wouter";
import InteractiveSpaceObject from "@/components/InteractiveSpaceObject";

const blackHole = "/manus-storage/wevlora-blackhole-lens_c312b594.png";

export default function Contact() {
  return (
    <main className="page inner-page contact-page">
      <section className="inner-hero contact-hero">
        <div className="inner-hero-copy"><p className="space-kicker"><span className="kicker-line" /> Contact dock · 05 / 05</p><h1>Make the next<br /><em>move visible.</em></h1><p>Tell us a little about what you are building. We’ll get back to you within 24 hours.</p></div>
        <div className="contact-hero-object"><InteractiveSpaceObject src={blackHole} alt="A luminous black-hole lens representing a new project signal" variant="blackhole" label="Open channel" detail="Drag the signal" destination="mailto:business.wevlora@gmail.com" actionLabel="Email Wevlora" /></div>
      </section>

      <section className="contact-dock content-section">
        <div className="section-index"><span>01</span><span className="index-rule" /></div>
        <div className="contact-dock-grid"><div className="contact-dock-copy"><p className="space-kicker"><span className="kicker-line" /> Start a conversation</p><h2>Bring us the idea.<br /><em>We’ll shape the experience.</em></h2><p>Bring the rough version, the half-formed thought, or the business that needs a better first impression. We’ll help find the clearest route forward.</p><a href="mailto:business.wevlora@gmail.com" className="space-button button-filled"><span>Email Wevlora</span><ArrowUpRight size={16} /></a></div><div className="contact-channels"><div className="contact-channel-label">Direct channels</div><a href="mailto:business.wevlora@gmail.com" className="contact-channel"><span className="channel-icon"><Mail size={16} /></span><span><small>Email</small><strong>business.wevlora@gmail.com</strong></span><ArrowUpRight size={15} /></a><a href="tel:7477348662" className="contact-channel"><span className="channel-icon"><Phone size={16} /></span><span><small>Call / WhatsApp</small><strong>7477348662</strong></span><ArrowUpRight size={15} /></a><a href="https://instagram.com/wevlora" target="_blank" rel="noreferrer" className="contact-channel"><span className="channel-icon"><Instagram size={16} /></span><span><small>Instagram</small><strong>@wevlora</strong></span><ArrowUpRight size={15} /></a></div></div>
      </section>

      <section className="contact-finish content-section"><div className="finish-panel"><p className="space-kicker"><span className="kicker-line" /> Local team · always reachable</p><h2>See you on<br /><em>the other side.</em></h2><Link href="/" className="space-text-link">Return to home <ArrowUpRight size={16} /></Link></div></section>
    </main>
  );
}

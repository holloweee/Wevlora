/**
 * Celestial Glass Studio — About page.
 * Tells the real Wevlora story through a living glass terrarium and the original creator team.
 */
import { ArrowUpRight, Check, Clock3, HeartHandshake, MapPin } from "lucide-react";
import { Link } from "wouter";
import InteractiveSpaceObject from "@/components/InteractiveSpaceObject";

const principles = [
  { icon: <Check size={16} />, title: "Built for you", detail: "Custom websites, not templates." },
  { icon: <Clock3 size={16} />, title: "Fast delivery", detail: "Ready in 3–5 days." },
  { icon: <HeartHandshake size={16} />, title: "Premium, not precious", detail: "Fair pricing, thoughtful work." },
  { icon: <MapPin size={16} />, title: "Always available", detail: "A local team, always reachable." },
];

const creators = [
  { initial: "O", name: "Oishi Pal Choudhary", role: "Manager & Client Relations", detail: "The face of Wevlora. Oishi Pal Choudhary handles client communication, pitching, and project management with warmth and precision." },
  { initial: "A", name: "Amlan Debnath", role: "CEO • Planner & Lead Builder", detail: "The strategist. Amlan Debnath plans every project from the ground up and leads website development with sharp attention to detail." },
  { initial: "A", name: "Anik Mandal", role: "Builder & Developer", detail: "The builder. Anik Mandal works alongside Amlan Debnath to craft and develop websites that are fast, beautiful, and fully functional." },
];

export default function About() {
  return (
    <main className="page inner-page about-page">
      <section className="inner-hero">
        <div className="inner-hero-copy"><p className="space-kicker"><span className="kicker-line" /> About the studio · 02 / 05</p><h1>Three creators.<br /><em>One goal.</em></h1><p>We are a small passionate team from West Bengal, India. We believe every business deserves a stunning online presence — and we build exactly that.</p></div>
        <div className="inner-hero-orbit" aria-hidden="true"><span /><span /><span /></div>
      </section>

      <section className="about-field content-section">
        <div className="section-index"><span>01</span><span className="index-rule" /></div>
        <div className="about-field-grid">
          <div className="about-object-wrap"><InteractiveSpaceObject alt="A leafy plant inside a translucent glass terrarium" variant="terrarium" label="Living / 01" detail="Drag the dome" destination="/about" actionLabel="Meet the creators" /></div>
          <div className="about-field-copy"><p className="space-kicker"><span className="kicker-line" /> A small team, close to the work</p><h2>Local roots.<br /><em>Long reach.</em></h2><p>Wevlora is a small creative agency based in West Bengal, India. The team stays close to every project, which keeps the work personal, the feedback fast, and the handover straightforward.</p><p>Our aim is simple: give ambitious local businesses a better digital presence without agency distance or unnecessary complexity.</p><Link href="/services" className="space-text-link">See what we make <ArrowUpRight size={16} /></Link></div>
        </div>
      </section>

      <section className="creators-section content-section">
        <div className="section-index"><span>02</span><span className="index-rule" /></div>
        <div className="section-intro-row"><div><p className="space-kicker"><span className="kicker-line" /> The original creators</p><h2>Meet the<br /><em>team.</em></h2></div><p className="section-lede">Three roles, one close-working rhythm, and a shared belief that good websites should feel as human as the people behind them.</p></div>
        <div className="creators-grid">{creators.map((creator) => <article className="creator-card" key={creator.name}><div className="creator-avatar">{creator.initial}</div><div className="creator-card-meta"><strong>{creator.name}</strong><span>{creator.role}</span></div><p>{creator.detail}</p></article>)}</div>
      </section>

      <section className="principles-section content-section">
        <div className="section-index"><span>03</span><span className="index-rule" /></div>
        <div className="section-intro-row"><div><p className="space-kicker"><span className="kicker-line" /> What matters here</p><h2>Good work<br /><em>stays human.</em></h2></div><p className="section-lede">We care about the details, but we never make the details harder than they need to be.</p></div>
        <div className="principles-grid">{principles.map((principle) => <div className="principle-card" key={principle.title}><span className="principle-icon">{principle.icon}</span><strong>{principle.title}</strong><p>{principle.detail}</p></div>)}</div>
      </section>

      <section className="about-quote content-section"><p className="space-kicker"><span className="kicker-line" /> Our north star</p><blockquote>“Every business deserves a stunning online presence.”</blockquote><span>— Wevlora Creative Agency</span></section>
    </main>
  );
}

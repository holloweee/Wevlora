/**
 * Celestial Glass Studio — Home page.
 * Introduces Wevlora through an interactive black-hole lens and a clearer digital signal.
 */
import { ArrowDownRight, ArrowUpRight, Orbit, Sparkles } from "lucide-react";
import { Link } from "wouter";
import InteractiveSpaceObject from "@/components/InteractiveSpaceObject";

const blackHole = "/manus-storage/wevlora-blackhole-lens_c312b594.png";

export default function Home() {
  return (
    <main className="page home-page">
      <section className="page-hero home-hero">
        <div className="hero-cosmic-rings" aria-hidden="true"><span /><span /><span /></div>
        <div className="page-hero-copy">
          <p className="space-kicker"><span className="kicker-line" /> Creative agency · WB / IN</p>
          <h1>Build something<br /><em>people can find.</em></h1>
          <p className="hero-lede">We design and build professional websites for businesses that want to stand out, attract customers, and grow online.</p>
          <div className="hero-cta-row">
            <Link href="/contact" className="space-button button-filled"><span>Start a project</span><ArrowUpRight size={16} /></Link>
            <Link href="/services" className="space-text-link"><span>View services</span><ArrowDownRight size={16} /></Link>
          </div>
          <div className="hero-signal"><span className="signal-pulse" /> Taking on a few new projects · 2026</div>
        </div>
        <div className="page-hero-object">
          <InteractiveSpaceObject src={blackHole} alt="A dark glass black-hole lens with a luminous teal event horizon" variant="blackhole" label="Signal / 01" detail="Drag the horizon" destination="/services" actionLabel="Explore services" />
          <div className="hero-coordinate">12° 58' 04" N<br /><span>West Bengal, India</span></div>
        </div>
        <div className="hero-bottom-note"><span>Scroll to explore</span><span className="down-stem" /></div>
      </section>

      <section className="home-proof content-section">
        <div className="section-index"><span>01</span><span className="index-rule" /></div>
        <div className="section-intro-row">
          <div><p className="space-kicker"><span className="kicker-line" /> A clear signal</p><h2>A better first<br /><em>impression.</em></h2></div>
          <p className="section-lede">A website is often the first room your customer walks into. We make the room worth staying in — considered, useful, and unmistakably yours.</p>
        </div>
        <div className="proof-grid">
          <div className="proof-card proof-card-large"><span className="proof-icon"><Orbit size={18} /></span><strong>Custom by default</strong><p>Built for your business, not pulled from a template library.</p><Link href="/about" className="proof-link">Meet the studio <ArrowUpRight size={15} /></Link></div>
          <div className="proof-card"><span className="proof-number">03</span><strong>Team members</strong><p>A small studio means direct care and fast decisions.</p></div>
          <div className="proof-card"><span className="proof-number">05</span><strong>Days avg delivery</strong><p>Momentum without making you wait around.</p></div>
          <div className="proof-card"><span className="proof-number">100%</span><strong>Client ownership</strong><p>Your business, your website, your keys.</p></div>
        </div>
      </section>

      <section className="home-route content-section">
        <div className="section-index"><span>02</span><span className="index-rule" /></div>
        <div className="route-panel">
          <div className="route-panel-copy"><p className="space-kicker"><span className="kicker-line" /> The studio route</p><h2>From idea<br /><em>to orbit.</em></h2><p>We keep the process close, the language clear, and the final handover completely yours.</p><Link href="/about" className="space-text-link">See how we work <ArrowUpRight size={16} /></Link></div>
          <div className="route-lines" aria-hidden="true"><span /><span /><span /><span /></div>
          <div className="route-meta"><Sparkles size={16} /><span>West Bengal, India</span><small>Local team · always reachable</small></div>
        </div>
      </section>
    </main>
  );
}

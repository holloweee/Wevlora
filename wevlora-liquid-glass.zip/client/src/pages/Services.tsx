/**
 * Celestial Glass Studio — Services page.
 * Turns Wevlora's real service list into a clear planetary system with interactive depth.
 */
import { ArrowUpRight, CircleDot, Globe2, Mail, Smartphone, Utensils, Wrench } from "lucide-react";
import { Link } from "wouter";
import InteractiveSpaceObject from "@/components/InteractiveSpaceObject";

const services = [
  { number: "01", icon: <Globe2 size={18} />, title: "Business website design", text: "A clear, considered website that gives your business a better first impression.", tag: "Presence" },
  { number: "02", icon: <Utensils size={18} />, title: "Restaurant & hospitality websites", text: "Atmospheric digital spaces that make it easier for guests to choose you.", tag: "Experience" },
  { number: "03", icon: <CircleDot size={18} />, title: "Table reservation systems", text: "Simple booking paths that turn interest into a confirmed visit.", tag: "Conversion" },
  { number: "04", icon: <Smartphone size={18} />, title: "Mobile-optimised development", text: "Thoughtful responsive details for the screens your customers actually use.", tag: "Reach" },
  { number: "05", icon: <Mail size={18} />, title: "Email & contact integration", text: "Useful connective tissue so every enquiry lands in the right place.", tag: "Flow" },
  { number: "06", icon: <Wrench size={18} />, title: "Ongoing website support", text: "A local creative partner when the next update, idea, or improvement arrives.", tag: "Continuity" },
];

export default function Services() {
  return (
    <main className="page inner-page services-page">
      <section className="inner-hero services-hero">
        <div className="inner-hero-copy"><p className="space-kicker"><span className="kicker-line" /> Services · 03 / 05</p><h1>Give your business<br /><em>a wider orbit.</em></h1><p>From first impression to final click, we build useful digital spaces that help the right people find you.</p></div>
        <div className="services-hero-object"><InteractiveSpaceObject alt="A luminous glass planet with thin orbit rings" variant="planet" label="Services / 06" detail="Drag the orbit" destination="/contact" actionLabel="Plan a project" /></div>
      </section>

      <section className="services-list-section content-section">
        <div className="section-index"><span>01</span><span className="index-rule" /></div>
        <div className="section-intro-row"><div><p className="space-kicker"><span className="kicker-line" /> What we do</p><h2>Useful by<br /><em>design.</em></h2></div><p className="section-lede">Every service is shaped around your business, your customers, and the next useful step.</p></div>
        <div className="service-orbit-list">{services.map((service) => <Link href="/contact" className="service-orbit-row" key={service.number}><span className="service-orbit-number">{service.number}</span><span className="service-orbit-icon">{service.icon}</span><span className="service-orbit-copy"><strong>{service.title}</strong><span>{service.text}</span></span><span className="service-orbit-tag">{service.tag}</span><span className="service-orbit-arrow"><ArrowUpRight size={17} /></span></Link>)}</div>
      </section>

      <section className="services-process content-section"><div className="process-panel"><p className="space-kicker"><span className="kicker-line" /> One studio, one clear path</p><h2>Bring the idea.<br /><em>We’ll shape the experience.</em></h2><p>Share what you need, and we’ll plan the simplest route from intention to launch.</p><Link href="/contact" className="space-button button-outline"><span>Start a conversation</span><ArrowUpRight size={16} /></Link></div></section>
    </main>
  );
}

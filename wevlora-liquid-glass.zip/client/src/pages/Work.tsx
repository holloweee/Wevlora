/**
 * Celestial Glass Studio — Work page.
 * Keeps the current portfolio honest: an observatory waiting for the next projects to land.
 */
import { ArrowUpRight, Telescope } from "lucide-react";
import { Link } from "wouter";

export default function Work() {
  return (
    <main className="page inner-page work-page">
      <section className="inner-hero work-hero">
        <div className="inner-hero-copy"><p className="space-kicker"><span className="kicker-line" /> Work observatory · 04 / 05</p><h1>The next signal<br /><em>is forming.</em></h1><p>We are preparing a collection of recent work. Until then, the studio is open for the next project worth making visible.</p></div>
        <div className="work-hero-mark"><Telescope size={22} /><span>Portfolio status</span><strong>Coming soon</strong></div>
      </section>

      <section className="work-observatory content-section">
        <div className="observatory-stars" aria-hidden="true" />
        <div className="observatory-shade" />
        <div className="observatory-art" aria-hidden="true"><span className="observatory-ring ring-one" /><span className="observatory-ring ring-two" /><span className="observatory-aperture" /><span className="observatory-tick tick-one" /><span className="observatory-tick tick-two" /></div>
        <div className="observatory-content"><p className="space-kicker light-kicker"><span className="kicker-line" /> Current coordinates</p><h2>Good work<br /><em>takes shape.</em></h2><p>When the first orbit is complete, we’ll bring the case studies here. No filler, no invented client stories — just the work.</p><Link href="/contact" className="space-button button-light"><span>Be part of the next orbit</span><ArrowUpRight size={16} /></Link></div><span className="observatory-code">WVL / 04 / OBSERVATORY</span>
      </section>

      <section className="work-note content-section"><div className="section-index"><span>01</span><span className="index-rule" /></div><div className="work-note-grid"><div><p className="space-kicker"><span className="kicker-line" /> A note on proof</p><h2>Nothing<br /><em>made up.</em></h2></div><p className="section-lede">We’d rather show you real work when it’s ready than fill the page with generic placeholders. If you’re looking for a website that feels considered from the first frame, let’s start there.</p></div></section>
    </main>
  );
}

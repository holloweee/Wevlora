# Wevlora design direction

## Three possible directions

### Theme Name: Quiet Chromatic Glass
Very brief intro: A light editorial system with transparent surfaces, mineral color shifts, and a calm premium mood. It keeps Wevlora's existing restraint but gives the interface tactile depth.
Probability: 0.07

### Theme Name: Monsoon Signal
Very brief intro: A dark atmospheric direction built from deep ink, wet reflections, and controlled electric accents. It would feel cinematic and high-contrast while still staying professional.
Probability: 0.03

### Theme Name: Soft Geometry Studio
Very brief intro: A warm off-white studio palette with inflated 3D forms, sculptural typography, and a more approachable agency personality. It feels crafted, friendly, and highly ownable.
Probability: 0.08

## Chosen approach: Quiet Chromatic Glass

### Design Movement
Contemporary editorial minimalism fused with liquid-glass skeuomorphism: the discipline of a print layout, the tactile behavior of translucent material, and the spatial confidence of a 3D art direction.

### Core Principles
1. Keep the content editorial and direct; use depth for hierarchy, not decoration.
2. Pair hard typographic structure with soft, refractive surfaces.
3. Use asymmetry and diagonal movement to make the page feel composed rather than templated.
4. Let interaction feel physical: hover, drag, and focus states should suggest tension, release, and refraction.

### Color Philosophy
The base is a warm paper-white and graphite ink, echoing Wevlora's current monochrome identity. A signature mineral teal acts as the ownable brand color, while translucent pearl, pale lilac, and oxidized blue appear as refracted secondary tints inside glass. Color should feel like light passing through a material, not like a flat gradient pasted on top.

### Layout Paradigm
A stacked editorial canvas with offset columns, oversized section numbers, and a floating navigation rail. Hero content anchors left while a 3D glass orb occupies the opposite field; lower sections alternate between wide text bands and floating modular cards. The layout should rarely center everything on one axis.

### Signature Elements
- A refractive 3D orb / lens as the visual anchor, with a soft shadow and liquid highlight.
- Frosted glass panels with fine inner borders, grain, and chromatic edge glow.
- Large italic serif phrases paired with compressed uppercase metadata and thin rule lines.

### Interaction Philosophy
Every interactive element should feel like a small physical object. Buttons press down slightly, glass panels lift and refract on hover, and the navigation indicator glides like a droplet. Keyboard focus must remain clearly visible and elegant.

### Animation
Use slow orbital motion for the hero orb and barely perceptible float for decorative blobs. Section entries should use a 30–60ms stagger with opacity and translate only. Hover transitions stay under 240ms with a custom ease-out. Respect prefers-reduced-motion by freezing orbital and float effects while preserving opacity transitions.

### Typography System
Use Cormorant Garamond for the editorial display voice and DM Sans for navigation, labels, and body copy. Headlines are large, tightly tracked, and allowed to wrap in expressive lines; metadata is 10–11px uppercase with generous tracking; body copy stays 16–18px with a relaxed line-height.

### Brand Essence
Wevlora is the small, fast creative agency for ambitious local businesses that need a distinctive website without agency overhead; different because it combines premium design taste with direct, accountable delivery. Personality: precise, warm, quietly bold.

### Brand Voice
Headlines should be confident and tactile. CTAs should be active and human, never corporate. Microcopy should sound like a helpful studio that knows the work.
Example lines: “Give your business a better first impression.” / “Bring us the idea. We’ll shape the experience.”

### Wordmark & Logo
Use the WEVLORA wordmark in wide-tracked uppercase serif, paired with a custom circular W / V monogram inside a dark liquid orb. The monogram should be treated as a symbol, not as plain text.

### Signature Brand Color
Mineral Teal — #7FD9CF, used as a luminous accent inside glass edges, active states, and small moments of contrast.

## Implementation reminders
- Keep this design philosophy at the top of each edited CSS/component/page file.
- Use generated visual assets for the hero orb and supporting 3D texture, not generic placeholder art.
- Preserve the source site's actual business information: three-person team, 3–5 day delivery, West Bengal, services, process, phone, email, Instagram.
- Do not fabricate project case studies, reviews, ratings, or testimonials.


## Revision: Celestial Glass Studio

The redesign now extends the Quiet Chromatic Glass language into a **Celestial Glass Studio** system: dark observatory space, translucent glass planets, slow star fields, black-hole depth, and restrained botanical life. The original Wevlora logo remains the brand anchor and is not replaced by a generated mark.

### Information architecture
The experience is split into five distinct routes: `/` Home, `/about` About, `/services` Services, `/work` Work, and `/contact` Contact. Shared navigation, logo, footer, ambient star field, and interactive 3D object behavior should make the routes feel like connected rooms in one universe rather than separate templates.

### Visual system
Use deep ink-black as the base, with mineral teal, ultraviolet, nebula lavender, and moonstone white as refracted accents. Use large editorial serif headlines and restrained sans-serif metadata. Space should feel tactile and quiet instead of noisy: stars are sparse, nebulae are soft, and black-hole shapes create focus. Plants appear as a small living counterpoint inside glass domes, especially on About and Work.

### Page roles
Home introduces the agency through a responsive 3D black-hole lens and fast proof points. About explains the three-person West Bengal team using a glass terrarium and the studio's principles. Services presents each offering as a planetary orbit card. Work treats the current portfolio honestly as an observatory / coming-soon area, without fabricated case studies. Contact is an invitation dock with direct email, phone, and Instagram routes plus an interactive glass planet.

### Interaction contract
3D objects must respond to pointer movement, touch drag, and hover where supported. Objects should tilt, orbit, or reveal parallax layers based on user input; they should not be static images. Use CSS perspective, pointer coordinates, and transform/opacity transitions only. Add clear focus states and a reduced-motion mode that freezes orbital motion while preserving usable layout.

### Signature motifs
- A refractive black-hole lens with an event-horizon ring as the primary interactive object.
- Glass terrariums and small plants as living studio metaphors.
- Page-to-page route labels styled like astronomical coordinates, with thin orbital lines and tiny star markers.

### Brand voice update
Keep the direct, human Wevlora voice, but allow the space metaphor to shape headlines: “Make your next move visible.” “Build something people can find.” “A clearer signal for your business.” Avoid fantasy or sci-fi jargon that makes the agency feel less approachable.

# Wevlora Workspace — Setup Guide
Follow these steps exactly. Takes about 20–30 minutes.

---

## PART 1 — Run the app on your computer (do this first)

### Step 1 — Install Node.js
Go to https://nodejs.org and download the LTS version. Install it normally.
To check it worked, open Terminal (or Command Prompt on Windows) and type:
```
node --version
```
It should show a version number like v20.x.x

---

### Step 2 — Set up the backend
Open Terminal and run these commands one by one:

```bash
cd wevlora-workspace/backend
npm install
node server.js
```

You should see: `Wevlora backend running on port 3001`
Leave this terminal window open.

---

### Step 3 — Open the frontend
Open `wevlora-workspace/frontend/index.html` in your browser.
Default password is: **wevlora2024**
(Change it in index.html — search for TEAM_PASSWORD)

✅ The app works locally now. Projects, clients, invoices all save to `backend/data.json`.

---

## PART 2 — Connect Gmail (so enquiries auto-appear)

### Step 4 — Create a Google Cloud project
1. Go to https://console.cloud.google.com
2. Click "New Project" → name it "Wevlora" → Create
3. In the left menu → APIs & Services → Library
4. Search "Gmail API" → click it → Enable

---

### Step 5 — Create credentials
1. Go to APIs & Services → Credentials
2. Click "Create Credentials" → OAuth client ID
3. If asked for consent screen:
   - User Type: External → Create
   - App name: Wevlora → your email → Save
   - Scopes: skip → Save
   - Test users: add business.wevlora@gmail.com → Save
4. Back to Credentials → Create Credentials → OAuth client ID
   - Application type: **Desktop app**
   - Name: Wevlora Local
   - Create → Download JSON
5. Rename the downloaded file to `credentials.json`
6. Move it into the `wevlora-workspace/backend/` folder

---

### Step 6 — Authorize Gmail
Open a NEW terminal window (keep the server running in the other one):

```bash
cd wevlora-workspace/backend
node setup-gmail.js
```

It will print a long URL. Open that URL in your browser.
Sign in with **business.wevlora@gmail.com**.
You'll see a warning "Google hasn't verified this app" — click "Advanced" → "Go to Wevlora (unsafe)" → Allow.
Copy the code it gives you. Paste it back in the terminal. Press Enter.

You should see: ✅ token.json saved! Gmail is now connected.

---

### Step 7 — Test it
In the app, click "↻ Sync Gmail" in the sidebar.
Any messages Formspree has sent to business.wevlora@gmail.com will appear in Enquiries!

---

## PART 3 — Put it online (so your whole team can use it)

### Step 8 — Deploy backend to Render
1. Go to https://render.com → Sign up (free, no credit card)
2. Create a new "Web Service"
3. Connect your GitHub (upload the backend folder as a repo first)
   OR use "Deploy from existing repo"
4. Settings:
   - Build Command: `npm install`
   - Start Command: `node server.js`
5. After it deploys, copy your Render URL (like `https://wevlora-backend.onrender.com`)

---

### Step 9 — Update the frontend to use Render URL
In `frontend/index.html`, find this line:
```
const API = 'http://localhost:3001/api';
```
Change it to:
```
const API = 'https://your-app-name.onrender.com/api';
```

---

### Step 10 — Host the frontend (free options)
Option A — Netlify (easiest):
1. Go to https://netlify.com → Sign up
2. Drag the `frontend` folder onto the Netlify dashboard
3. Done! You get a URL like `https://wevlora-workspace.netlify.app`

Option B — Just share the HTML file with your team and they open it locally.

---

## Changing the team password
Open `frontend/index.html` and find:
```javascript
const TEAM_PASSWORD = 'wevlora2024';
```
Change it to whatever you want.

---

## Summary of what the app does
- 📥 **Enquiries** — auto-pulls from Gmail every 5 minutes, or click Sync
- 📋 **Projects** — kanban board (To Do / Ongoing / Done)
- 👥 **Clients** — store contact info, link to projects
- 🧾 **Invoices** — create itemized bills, mark paid/unpaid, download as PDF
- → **Convert** — one-click convert an enquiry to a client

## If anything breaks
The app works offline too — if the backend is down, everything saves to the browser's localStorage automatically. No data is lost.

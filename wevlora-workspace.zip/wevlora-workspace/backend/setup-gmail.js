// Run this once locally to generate token.json
// Usage: node setup-gmail.js

const { google } = require('googleapis');
const fs = require('fs');
const readline = require('readline');
const path = require('path');

const CREDS_PATH = path.join(__dirname, 'credentials.json');
const TOKEN_PATH = path.join(__dirname, 'token.json');

if (!fs.existsSync(CREDS_PATH)) {
  console.error('❌ credentials.json not found! Please download it from Google Cloud Console first.');
  process.exit(1);
}

const creds = JSON.parse(fs.readFileSync(CREDS_PATH));
const { client_secret, client_id, redirect_uris } = creds.installed || creds.web;
const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

const authUrl = oAuth2Client.generateAuthUrl({
  access_type: 'offline',
  scope: ['https://www.googleapis.com/auth/gmail.readonly'],
});

console.log('\n✅ Open this URL in your browser and authorize with business.wevlora@gmail.com:\n');
console.log(authUrl);
console.log('\n');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question('Paste the authorization code here: ', async (code) => {
  rl.close();
  try {
    const { tokens } = await oAuth2Client.getToken(code);
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(tokens));
    console.log('\n✅ token.json saved! Gmail is now connected.\n');
  } catch (err) {
    console.error('❌ Error getting token:', err.message);
  }
});

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');

const app = express();
app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'data.json');

// ─── Data helpers ───────────────────────────────────────────────
function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const initial = { projects: [], clients: [], invoices: [], enquiries: [], lastEmailCheck: null };
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ─── Gmail Setup ────────────────────────────────────────────────
function getGmailClient() {
  const credPath = path.join(__dirname, 'credentials.json');
  const tokenPath = path.join(__dirname, 'token.json');
  if (!fs.existsSync(credPath) || !fs.existsSync(tokenPath)) return null;

  const creds = JSON.parse(fs.readFileSync(credPath));
  const { client_secret, client_id, redirect_uris } = creds.installed || creds.web;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
  const token = JSON.parse(fs.readFileSync(tokenPath));
  oAuth2Client.setCredentials(token);
  return google.gmail({ version: 'v1', auth: oAuth2Client });
}

async function fetchNewEnquiries() {
  const gmail = getGmailClient();
  if (!gmail) return;

  const data = loadData();
  const since = data.lastEmailCheck
    ? Math.floor(new Date(data.lastEmailCheck).getTime() / 1000)
    : Math.floor(Date.now() / 1000) - 60 * 60 * 24 * 7; // last 7 days on first run

  try {
    const res = await gmail.users.messages.list({
      userId: 'me',
      q: `from:noreply@formspree.io after:${since}`,
      maxResults: 20,
    });

    const messages = res.data.messages || [];
    for (const msg of messages) {
      const full = await gmail.users.messages.get({ userId: 'me', id: msg.id, format: 'full' });
      const headers = full.data.payload.headers;
      const subject = headers.find(h => h.name === 'Subject')?.value || '(no subject)';
      const date = headers.find(h => h.name === 'Date')?.value || new Date().toISOString();

      // Parse body
      let body = '';
      const parts = full.data.payload.parts || [full.data.payload];
      for (const part of parts) {
        if (part.mimeType === 'text/plain' && part.body?.data) {
          body = Buffer.from(part.body.data, 'base64').toString('utf8');
          break;
        }
      }

      // Extract fields from Formspree email body
      const nameMatch = body.match(/name[:\s]+([^\n]+)/i);
      const emailMatch = body.match(/email[:\s]+([^\n]+)/i);
      const messageMatch = body.match(/message[:\s]+([\s\S]+?)(\n\n|$)/i);

      const already = data.enquiries.find(e => e.gmailId === msg.id);
      if (!already) {
        data.enquiries.unshift({
          id: 'enq_' + Date.now() + '_' + Math.random().toString(36).slice(2),
          gmailId: msg.id,
          name: nameMatch ? nameMatch[1].trim() : 'Unknown',
          email: emailMatch ? emailMatch[1].trim() : '',
          message: messageMatch ? messageMatch[1].trim() : body.slice(0, 300),
          subject,
          receivedAt: new Date(date).toISOString(),
          status: 'new', // new | contacted | converted | ignored
        });
      }
    }

    data.lastEmailCheck = new Date().toISOString();
    saveData(data);
  } catch (err) {
    console.error('Gmail fetch error:', err.message);
  }
}

// Poll Gmail every 5 minutes
fetchNewEnquiries();
setInterval(fetchNewEnquiries, 5 * 60 * 1000);

// ─── Auth Routes (Gmail OAuth) ───────────────────────────────────
app.get('/api/auth/status', (req, res) => {
  const hasCredentials = fs.existsSync(path.join(__dirname, 'credentials.json'));
  const hasToken = fs.existsSync(path.join(__dirname, 'token.json'));
  res.json({ connected: hasCredentials && hasToken });
});

app.get('/api/auth/url', (req, res) => {
  const credPath = path.join(__dirname, 'credentials.json');
  if (!fs.existsSync(credPath)) return res.status(400).json({ error: 'No credentials.json found' });
  const creds = JSON.parse(fs.readFileSync(credPath));
  const { client_secret, client_id, redirect_uris } = creds.installed || creds.web;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
  const url = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: ['https://www.googleapis.com/auth/gmail.readonly'],
  });
  res.json({ url });
});

app.post('/api/auth/token', async (req, res) => {
  const { code } = req.body;
  const credPath = path.join(__dirname, 'credentials.json');
  const creds = JSON.parse(fs.readFileSync(credPath));
  const { client_secret, client_id, redirect_uris } = creds.installed || creds.web;
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
  try {
    const { tokens } = await oAuth2Client.getToken(code);
    fs.writeFileSync(path.join(__dirname, 'token.json'), JSON.stringify(tokens));
    res.json({ success: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// ─── Enquiries ───────────────────────────────────────────────────
app.get('/api/enquiries', (req, res) => res.json(loadData().enquiries));

app.post('/api/enquiries', (req, res) => {
  const data = loadData();
  const enq = { id: 'enq_' + Date.now(), ...req.body, receivedAt: new Date().toISOString(), status: 'new' };
  data.enquiries.unshift(enq);
  saveData(data);
  res.json(enq);
});

app.patch('/api/enquiries/:id', (req, res) => {
  const data = loadData();
  const i = data.enquiries.findIndex(e => e.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  data.enquiries[i] = { ...data.enquiries[i], ...req.body };
  saveData(data);
  res.json(data.enquiries[i]);
});

// ─── Projects ────────────────────────────────────────────────────
app.get('/api/projects', (req, res) => res.json(loadData().projects));

app.post('/api/projects', (req, res) => {
  const data = loadData();
  const project = { id: 'proj_' + Date.now(), ...req.body, createdAt: new Date().toISOString() };
  data.projects.unshift(project);
  saveData(data);
  res.json(project);
});

app.patch('/api/projects/:id', (req, res) => {
  const data = loadData();
  const i = data.projects.findIndex(p => p.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  data.projects[i] = { ...data.projects[i], ...req.body };
  saveData(data);
  res.json(data.projects[i]);
});

app.delete('/api/projects/:id', (req, res) => {
  const data = loadData();
  data.projects = data.projects.filter(p => p.id !== req.params.id);
  saveData(data);
  res.json({ success: true });
});

// ─── Clients ─────────────────────────────────────────────────────
app.get('/api/clients', (req, res) => res.json(loadData().clients));

app.post('/api/clients', (req, res) => {
  const data = loadData();
  const client = { id: 'cli_' + Date.now(), ...req.body, createdAt: new Date().toISOString() };
  data.clients.unshift(client);
  saveData(data);
  res.json(client);
});

app.patch('/api/clients/:id', (req, res) => {
  const data = loadData();
  const i = data.clients.findIndex(c => c.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  data.clients[i] = { ...data.clients[i], ...req.body };
  saveData(data);
  res.json(data.clients[i]);
});

app.delete('/api/clients/:id', (req, res) => {
  const data = loadData();
  data.clients = data.clients.filter(c => c.id !== req.params.id);
  saveData(data);
  res.json({ success: true });
});

// ─── Invoices ────────────────────────────────────────────────────
app.get('/api/invoices', (req, res) => res.json(loadData().invoices));

app.post('/api/invoices', (req, res) => {
  const data = loadData();
  const num = String(data.invoices.length + 1).padStart(4, '0');
  const invoice = {
    id: 'inv_' + Date.now(),
    invoiceNumber: `WEV-${num}`,
    ...req.body,
    createdAt: new Date().toISOString(),
    status: 'unpaid',
  };
  data.invoices.unshift(invoice);
  saveData(data);
  res.json(invoice);
});

app.patch('/api/invoices/:id', (req, res) => {
  const data = loadData();
  const i = data.invoices.findIndex(inv => inv.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  data.invoices[i] = { ...data.invoices[i], ...req.body };
  saveData(data);
  res.json(data.invoices[i]);
});

app.delete('/api/invoices/:id', (req, res) => {
  const data = loadData();
  data.invoices = data.invoices.filter(inv => inv.id !== req.params.id);
  saveData(data);
  res.json({ success: true });
});

// ─── Site content (for website admin edits) ──────────────────────
app.get('/api/site', (req, res) => {
  const data = loadData();
  res.json(data.site || null);
});

app.post('/api/site', (req, res) => {
  const data = loadData();
  data.site = req.body;
  saveData(data);
  res.json({ ok: true });
});

// ─── Manual Gmail sync trigger ───────────────────────────────────
app.post('/api/sync', async (req, res) => {
  await fetchNewEnquiries();
  res.json({ success: true, message: 'Sync complete' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Wevlora backend running on port ${PORT}`));
